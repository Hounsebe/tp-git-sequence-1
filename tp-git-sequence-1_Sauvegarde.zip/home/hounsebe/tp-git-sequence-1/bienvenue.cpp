#include <iostream>

using namespace std;

int main (){
	cout << "Bienvenue le monde!" <<endl
return 0;
}
