# Mon projet de Gestion de configuration
Ce dépot est utilisé pour apprendre les bases de **GIT**

## Listes des fichiers
* bienvenue.cpp : le code source C++
* .gitignore : fichier qui ignore les fichiers issus de la fabrication
* README.md : le fichier de documentation
